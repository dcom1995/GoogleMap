
import UIKit
import GoogleMaps

class ViewController: UIViewController,CLLocationManagerDelegate {
    
    //MARK: - Variable Declaration
    
    /* Mapview */
    @IBOutlet weak var mapView: GMSMapView!
    
    /* Local Variables */
    var locationManager = CLLocationManager()
    var bounds = GMSCoordinateBounds()
    var currentMarker: GMSMarker!
    
    //MARK: - View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /* Display blue marker */
        //mapView.isMyLocationEnabled = true
        
        /* Call To update current location */
        locationManager.delegate = self
        locationManager.startUpdatingLocation()
        
        // Creates a marker in the center of the map.
        currentMarker = GMSMarker()
        currentMarker.title = "Current Location"
        currentMarker.snippet = "Ahmedabad"
        currentMarker.map = mapView
        currentMarker.icon = UIImage(named: "pickup_new.png")
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()        
    }
    
    // Get current location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations.first
        self.locationManager.stopUpdatingLocation()
        
        currentMarker.position = CLLocationCoordinate2D(latitude: (location?.coordinate.latitude)!, longitude: (location?.coordinate.longitude)!)
        
        mapView?.animate(to: GMSCameraPosition.camera(withTarget: currentMarker.position, zoom: 16.0))
        
    }
    
    /* Route Draw between two location */
    @IBAction func didTapRouteDraw(_ sender: Any) {
        
        let destinationMarker = GMSMarker()
        destinationMarker.position = CLLocationCoordinate2D(latitude: 21.1702, longitude: 72.8311)
        destinationMarker.title = "Destination"
        destinationMarker.snippet = "Surat"
        destinationMarker.icon = UIImage(named: "pickup_new.png")
        destinationMarker.map = mapView
        
        bounds = bounds.includingCoordinate(currentMarker.position)
        bounds = bounds.includingCoordinate(destinationMarker.position)
        
        getPolylineRoute(from: currentMarker.position, to: destinationMarker.position)
    }
    
    // Pass your source and destination coordinates in this method.
    func getPolylineRoute(from source: CLLocationCoordinate2D, to destination: CLLocationCoordinate2D) {
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        let url = URL(string: "http://maps.googleapis.com/maps/api/directions/json?origin=\(source.latitude),\(source.longitude)&destination=\(destination.latitude),\(destination.longitude)&sensor=false&mode=driving")!
        
        let task = session.dataTask(with: url, completionHandler: {
            (data, response, error) in
            if error != nil {
                print(error!.localizedDescription)
            }else{
                do {
                    if let json : [String:Any] = try JSONSerialization.jsonObject(with: data!, options: .allowFragments) as? [String: Any]{
                        
                        let preRoutes = json["routes"] as! NSArray
                        let routes = preRoutes[0] as! NSDictionary
                        let routeOverviewPolyline:NSDictionary = routes.value(forKey: "overview_polyline") as! NSDictionary
                        let polyString = routeOverviewPolyline.object(forKey: "points") as! String
                        
                        //Call this method to draw path on map
                        self.showPath(polyStr: polyString)
                    }
                    
                }catch{
                    print("error in JSONSerialization")
                }
            }
        })
        task.resume()
    }
    
    /* Show path */
    func showPath(polyStr :String) {
        let path = GMSPath(fromEncodedPath: polyStr)
        let polyline = GMSPolyline(path: path)
        polyline.strokeWidth = 3.0
        polyline.strokeColor = UIColor.red
        polyline.map = mapView // Your map view
       
        mapView.moveCamera(GMSCameraUpdate.fit(bounds, withPadding: 40.0))
    }
    
}

